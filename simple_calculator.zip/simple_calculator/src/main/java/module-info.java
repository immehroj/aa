module com.simple_calculator {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.simple_calculator to javafx.fxml;
    exports com.simple_calculator;
}