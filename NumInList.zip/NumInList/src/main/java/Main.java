import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;


public class Main {
    protected static Scanner scan = new Scanner(System.in);
    protected static String mysqlUrl = "jdbc:mysql://localhost/test1"; // URL вашей базы данных
    protected static Connection con;


    static {
        try {
            con = DriverManager.getConnection(mysqlUrl, "root", "root"); // Ваши учетные данные
            createTableIfNotExists(); // Создание таблицы, если она не существует
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();


        // Заполнение списка случайными числами
        System.out.print("Введите количество элементов списка: ");
        int n = scan.nextInt();
        System.out.print("Введите минимальное значение элементов списка: ");
        int min = scan.nextInt();
        System.out.print("Введите максимальное значение элементов списка: ");
        int max = scan.nextInt();


        for (int i = 0; i < n; i++) {
            int num = (int) (Math.random() * (max - min + 1) + min);
            list.add(num);
            saveToDatabase(num); // Сохранение числа в базе данных
        }


        System.out.println("Список: " + list);


        // Поиск числа в списке
        System.out.print("Введите число для поиска: ");
        int searchNum = scan.nextInt();
        int index = binarySearch(list, searchNum);


        if (index != -1) {
            System.out.println("Число " + searchNum + " найдено в списке на позиции " + index);
        } else {
            System.out.println("Число " + searchNum + " не найдено в списке");
        }


        // Вывод всех чисел из базы данных
        System.out.println("Числа из базы данных:");
        fetchFromDatabase();
    }


    // Метод для создания таблицы, если она не существует
    private static void createTableIfNotExists() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS numbers (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "value INT NOT NULL" +
                ")";


        try (PreparedStatement statement = con.prepareStatement(createTableSQL)) {
            statement.executeUpdate();
            System.out.println("Таблица 'numbers' успешно создана или уже существует.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Сохранение числа в базе данных
    private static void saveToDatabase(int number) {
        String query = "INSERT INTO numbers (value) VALUES (?)";


        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setInt(1, number);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Извлечение чисел из базы данных
    private static void fetchFromDatabase() {
        String query = "SELECT value FROM numbers";


        try (PreparedStatement statement = con.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {


            while (resultSet.next()) {
                System.out.print(resultSet.getInt("value") + " ");
            }
            System.out.println();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Бинарный поиск числа в отсортированном списке
    public static int binarySearch(ArrayList<Integer> list, int searchNum) {
        int left = 0;
        int right = list.size() - 1;


        while (left <= right) {
            int mid = (left + right) / 2;
            if (list.get(mid) == searchNum) {
                return mid;
            } else if (list.get(mid) < searchNum) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }


        return -1;
    }
}
