package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.demo.Model.MyAppUser;
import com.example.demo.Model.MyAppUserRepository;

@Controller
public class RegistrationController {

    @Autowired
    private MyAppUserRepository myAppUserRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Страница регистрации
    @GetMapping("/req/signup")
    public String signupForm(Model model) {
        model.addAttribute("user", new MyAppUser()); // Создаем новый объект для формы
        return "signup"; // Шаблон формы регистрации
    }

    // Обработка отправки формы регистрации
    @PostMapping("/req/signup")
    public String registerUser(@ModelAttribute MyAppUser user) {
        user.setPassword(passwordEncoder.encode(user.getPassword())); // Шифруем пароль
        myAppUserRepository.save(user); // Сохраняем пользователя в базе данных
        return "redirect:/req/login"; // Перенаправляем на страницу входа
    }
}
